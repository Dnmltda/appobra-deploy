#!/usr/bin/env node
'use strict';

/*
 * APP OBRA — supervisor + reverse proxy for Hostinger Node.js app hosting.
 *
 * CONFIRMED (via diagnostics on this exact hosting environment):
 *  - Hostinger requires the Node.js entry process itself to call listen()
 *    on process.env.PORT quickly, AND to KEEP holding that listening socket
 *    for the app's entire lifetime. Closing it and letting a different
 *    process (even one that rebinds the exact same port number) take over
 *    breaks Hostinger's own routing to the app — confirmed by a direct test
 *    where handing the port to PocketBase produced a consistent upstream
 *    504 from Hostinger's own nginx layer, even though PocketBase itself
 *    was alive and correctly listening on that port. This points to
 *    Hostinger (likely via a Passenger-style app manager) pinning its
 *    routing to the specific process/socket instance it saw bind at
 *    startup, not just "whatever is on this port now".
 *  - Separately, loopback TCP connections to any port NUMBER other than
 *    the assigned public port are blocked/refused — confirmed with a pure
 *    Node self-connect test, independent of PocketBase. This is why the
 *    original "proxy to an internal port like 8090" design never worked:
 *    PocketBase was running fine, but nothing could reach it there.
 *  - PocketBase does not support Unix domain sockets (--http is TCP-only).
 *
 * Putting these together, this script:
 *   1. Detects the container's own non-loopback IPv4 address and binds
 *      Node's own HTTP server to THAT specific address on PUBLIC_PORT —
 *      never 0.0.0.0, and never closed for the app's lifetime (satisfies
 *      the "Node must keep holding the socket" requirement).
 *   2. Spawns PocketBase bound to 127.0.0.1:PUBLIC_PORT — the SAME port
 *      NUMBER as the public port, just on the loopback interface, which
 *      does not conflict with Node's bind on the specific non-loopback
 *      address. If the host's network restriction is keyed on port number
 *      (not interface), this specific same-port loopback hop should be
 *      allowed where other internal ports were not.
 *   3. Node proxies every request to 127.0.0.1:PUBLIC_PORT, answering with
 *      an honest "starting up" placeholder until PocketBase is confirmed
 *      ready there.
 *
 * Every error path logs loudly instead of crashing silently, because a
 * silent crash here means Hostinger's platform has nothing to show and no
 * clear signal to restart on.
 */

const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const { spawn, execFile } = require('child_process');

console.log(`[server.js] host arch=${process.arch} platform=${process.platform} node=${process.version}`);
console.log(`[server.js] process.env.PORT=${process.env.PORT}`);

const PUBLIC_PORT = process.env.PORT || 8080;

// Detect the container's own non-loopback IPv4 address. Node's public
// listener binds to THIS specific address (never 0.0.0.0), leaving
// 127.0.0.1 on the same port number free for PocketBase.
function detectNonLoopbackIPv4() {
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const iface of ifaces[name] || []) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return null;
}
const PUBLIC_HOST = detectNonLoopbackIPv4();
console.log(`[server.js] detected non-loopback IPv4: ${PUBLIC_HOST}`);
const BIND_HOST = PUBLIC_HOST || '0.0.0.0';
if (!PUBLIC_HOST) {
  console.error('[server.js] WARNING: no non-loopback IPv4 detected, falling back to 0.0.0.0 (PocketBase same-port loopback trick will NOT work in this case).');
}

const ROOT = __dirname;
const PB_BINARY = path.join(ROOT, 'pocketbase');

process.on('uncaughtException', (err) => {
  console.error('[server.js] uncaughtException:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (err) => {
  console.error('[server.js] unhandledRejection:', err && err.stack ? err.stack : err);
});

if (!fs.existsSync(PB_BINARY)) {
  console.error(`[server.js] PocketBase binary not found at ${PB_BINARY}`);
  process.exit(1);
}

try {
  fs.chmodSync(PB_BINARY, 0o755);
} catch (err) {
  console.error('[server.js] Could not chmod PocketBase binary (continuing anyway):', err.message);
}

execFile(PB_BINARY, ['--version'], { timeout: 8000 }, (err, stdout, stderr) => {
  if (err) {
    console.error(`[server.js] SANITY CHECK FAILED: ${PB_BINARY} --version errored: ${err.message}`);
  } else {
    console.log(`[server.js] SANITY CHECK OK: ${PB_BINARY} --version -> ${stdout.trim() || stderr.trim()}`);
  }
});

// Copy pb_data to a local tmp dir before first start (fast; keeps the
// shipped copy under ROOT pristine in case we need to reset).
const PB_DATA_SRC = path.join(ROOT, 'pb_data');
const PB_DATA_RUN = path.join(os.tmpdir(), 'appobra_pb_data');
try {
  if (!fs.existsSync(PB_DATA_RUN)) {
    console.log(`[server.js] copying pb_data from ${PB_DATA_SRC} to local tmp dir ${PB_DATA_RUN}...`);
    fs.cpSync(PB_DATA_SRC, PB_DATA_RUN, { recursive: true });
    console.log(`[server.js] copy to ${PB_DATA_RUN} complete.`);
  } else {
    console.log(`[server.js] reusing existing local tmp pb_data at ${PB_DATA_RUN}.`);
  }
} catch (err) {
  console.error(`[server.js] failed to copy pb_data to ${PB_DATA_RUN}:`, err && err.stack ? err.stack : err);
}

// PocketBase binds the SAME port NUMBER as the public port, but only on
// loopback — this is the key difference from the earlier failed attempt
// (which used an unrelated port like 8090).
const PB_ARGS = [
  'serve',
  `--http=127.0.0.1:${PUBLIC_PORT}`,
  `--dir=${PB_DATA_RUN}`,
  `--migrationsDir=${path.join(ROOT, 'pb_migrations')}`,
  `--hooksDir=${path.join(ROOT, 'pb_hooks')}`,
  '--hooksWatch=false',
  `--publicDir=${path.join(ROOT, 'pb_public')}`,
];

let shuttingDown = false;
let pbProcess = null;
let pbReady = false;
let pbReadyPollTimer = null;

let pbPollAttempts = 0;
function pollPbReady() {
  if (pbReadyPollTimer) return;
  pbPollAttempts = 0;
  pbReadyPollTimer = setInterval(() => {
    pbPollAttempts++;
    const probe = http.request(
      { hostname: '127.0.0.1', port: PUBLIC_PORT, path: '/api/health', method: 'GET', timeout: 1000 },
      (res) => {
        res.resume();
        if (res.statusCode && res.statusCode < 500) {
          pbReady = true;
          clearInterval(pbReadyPollTimer);
          pbReadyPollTimer = null;
          console.log(`[server.js] PocketBase confirmed ready on 127.0.0.1:${PUBLIC_PORT} (after ${pbPollAttempts} probe attempts).`);
        } else {
          console.log(`[server.js] probe #${pbPollAttempts}: PocketBase responded with status ${res.statusCode}`);
        }
      }
    );
    probe.on('error', (err) => {
      if (pbPollAttempts <= 3 || pbPollAttempts % 10 === 0) {
        console.log(`[server.js] probe #${pbPollAttempts} to 127.0.0.1:${PUBLIC_PORT} failed: ${err.code || err.message}`);
      }
    });
    probe.on('timeout', () => {
      if (pbPollAttempts <= 3 || pbPollAttempts % 10 === 0) {
        console.log(`[server.js] probe #${pbPollAttempts} to 127.0.0.1:${PUBLIC_PORT} timed out`);
      }
      probe.destroy();
    });
    probe.end();
  }, 300);
}

// Route PocketBase's own stdout/stderr to a plain file and tail it into our
// own console.log — confirmed necessary in this environment.
const PB_LOG_FILE = path.join(os.tmpdir(), 'appobra_pb_output.log');
let pbLogTailPos = 0;
let pbLogTailTimer = null;
function startPbLogTail() {
  if (pbLogTailTimer) return;
  pbLogTailPos = 0;
  pbLogTailTimer = setInterval(() => {
    try {
      const st = fs.statSync(PB_LOG_FILE);
      if (st.size > pbLogTailPos) {
        const fd = fs.openSync(PB_LOG_FILE, 'r');
        const len = st.size - pbLogTailPos;
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, pbLogTailPos);
        fs.closeSync(fd);
        pbLogTailPos = st.size;
        buf.toString('utf8').split('\n').filter((l) => l.length > 0).forEach((line) => {
          console.log(`[pocketbase-output] ${line}`);
        });
      }
    } catch (err) {
      if (err.code !== 'ENOENT') {
        console.error('[server.js] error tailing pb log file:', err.message);
      }
    }
  }, 1000);
}

function startPocketBase() {
  console.log(`[server.js] starting (pid will follow): ${PB_BINARY} ${PB_ARGS.join(' ')}`);

  let child;
  let logFd;
  try {
    fs.writeFileSync(PB_LOG_FILE, '');
    pbLogTailPos = 0;
    logFd = fs.openSync(PB_LOG_FILE, 'a');
  } catch (err) {
    console.error('[server.js] could not prepare pb log file, falling back to inherit:', err.message);
    logFd = 'inherit';
  }
  try {
    child = spawn(PB_BINARY, PB_ARGS, {
      cwd: ROOT,
      stdio: logFd === 'inherit' ? 'inherit' : ['ignore', logFd, logFd],
      env: process.env,
    });
    if (logFd !== 'inherit') {
      try { fs.closeSync(logFd); } catch (e) { /* parent's dup; child keeps its own */ }
    }
  } catch (err) {
    console.error('[server.js] spawn() threw synchronously:', err);
    if (!shuttingDown) setTimeout(startPocketBase, 3000);
    return null;
  }

  startPbLogTail();
  console.log(`[server.js] PocketBase child spawned with pid=${child.pid}`);

  const watchdogChild = child;
  const watchdogTimer = setTimeout(() => {
    if (!pbReady && pbProcess === watchdogChild && !shuttingDown) {
      console.error(`[server.js] watchdog: PocketBase (pid=${watchdogChild.pid}) did not become ready within 25s, killing and retrying.`);
      try {
        watchdogChild.kill('SIGKILL');
      } catch (e) {
        console.error('[server.js] watchdog kill failed:', e.message);
      }
    }
  }, 25000);

  child.on('exit', (code, signal) => {
    clearTimeout(watchdogTimer);
    console.error(`[server.js] PocketBase (pid=${child.pid}) exited (code=${code}, signal=${signal}).`);
    pbReady = false;
    pollPbReady();
    if (!shuttingDown) {
      setTimeout(() => {
        pbProcess = startPocketBase();
      }, 3000);
    }
  });

  child.on('error', (err) => {
    console.error('[server.js] Failed to start PocketBase binary:', err);
  });

  return child;
}

pbProcess = startPocketBase();
pollPbReady();

// --- Reverse proxy: opens PUBLIC_PORT on the container's own non-loopback
// address immediately (Hostinger health check), and NEVER closes it for
// the app's lifetime. Forwards everything to PocketBase on
// 127.0.0.1:PUBLIC_PORT (same port number, loopback only). ---

const proxyServer = http.createServer((clientReq, clientRes) => {
  if (!pbReady) {
    clientRes.writeHead(200, { 'Content-Type': 'text/plain' });
    clientRes.end('APP OBRA is starting up, please retry in a moment.');
    return;
  }

  const proxyReq = http.request(
    {
      hostname: '127.0.0.1',
      port: PUBLIC_PORT,
      path: clientReq.url,
      method: clientReq.method,
      headers: clientReq.headers,
    },
    (proxyRes) => {
      clientRes.writeHead(proxyRes.statusCode, proxyRes.headers);
      proxyRes.pipe(clientRes, { end: true });
    }
  );

  proxyReq.on('error', (err) => {
    pbReady = false;
    pollPbReady();
    if (!clientRes.headersSent) {
      clientRes.writeHead(200, { 'Content-Type': 'text/plain' });
    }
    clientRes.end('APP OBRA is restarting, please retry in a moment.');
  });

  clientReq.pipe(proxyReq, { end: true });
});

proxyServer.on('upgrade', (req, clientSocket, head) => {
  const proxyReq = http.request({
    hostname: '127.0.0.1',
    port: PUBLIC_PORT,
    path: req.url,
    method: req.method,
    headers: req.headers,
  });
  proxyReq.on('upgrade', (proxyRes, proxySocket, proxyHead) => {
    clientSocket.write(
      `HTTP/1.1 101 Switching Protocols\r\n` +
        Object.entries(proxyRes.headers)
          .map(([k, v]) => `${k}: ${v}`)
          .join('\r\n') +
        '\r\n\r\n'
    );
    proxySocket.pipe(clientSocket);
    clientSocket.pipe(proxySocket);
  });
  proxyReq.on('error', () => clientSocket.destroy());
  proxyReq.end();
});

function listenWithRetry() {
  proxyServer.listen(PUBLIC_PORT, BIND_HOST, () => {
    console.log(`[server.js] reverse proxy listening on ${BIND_HOST}:${PUBLIC_PORT}, forwarding to 127.0.0.1:${PUBLIC_PORT}`);
  });
}

proxyServer.on('error', (err) => {
  console.error(`[server.js] proxy server error (code=${err.code}):`, err.message);
  if (err.code === 'EADDRINUSE' && !shuttingDown) {
    console.error('[server.js] port still in use, retrying listen() in 1s...');
    setTimeout(() => {
      try { proxyServer.close(); } catch (e) { /* ignore */ }
      listenWithRetry();
    }, 1000);
  }
});

listenWithRetry();

function shutdown(signal) {
  console.log(`[server.js] received ${signal}, shutting down...`);
  shuttingDown = true;
  if (pbReadyPollTimer) {
    clearInterval(pbReadyPollTimer);
    pbReadyPollTimer = null;
  }
  if (pbProcess && !pbProcess.killed) {
    pbProcess.kill(signal);
  }
  try {
    proxyServer.close(() => process.exit(0));
  } catch (e) {
    process.exit(0);
  }
  setTimeout(() => process.exit(0), 2000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
