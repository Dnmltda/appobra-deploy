#!/usr/bin/env node
'use strict';

/*
 * APP OBRA — launcher for Hostinger Node.js app hosting.
 *
 * CONFIRMED (via diagnostics on this exact hosting environment):
 *  - Hostinger requires the Node.js entry process to call listen() on
 *    process.env.PORT quickly, AND it routes traffic to that SAME process
 *    for the app's whole lifetime — if the entry process's listening
 *    socket closes and a DIFFERENT process (even one that rebinds the
 *    exact same port number) takes over, Hostinger's own edge starts
 *    returning a consistent 504, even though the new process is correctly
 *    listening. This points to routing pinned to the specific process
 *    instance, not just "whatever is on this port now".
 *  - Separately, loopback TCP connections to any port NUMBER other than
 *    the assigned public port are blocked — confirmed with a pure
 *    Node-to-Node self-connect test. So a "Node proxies to PocketBase on
 *    a different internal port" design can never work here either.
 *  - PocketBase does not support Unix domain sockets (--http is TCP-only),
 *    and this environment has no secondary, non-loopback network
 *    interface to exploit a same-port-different-host trick.
 *
 * The fix that satisfies BOTH constraints at once: instead of spawning
 * PocketBase as a SEPARATE process (new PID) or proxying to it over the
 * network, this script turns the running Node process ITSELF into
 * PocketBase via execve() — the exact same OS process (same PID) that
 * Hostinger spawned and health-checked simply becomes PocketBase's process
 * image. No new process is ever created, so there is nothing for
 * Hostinger's routing to lose track of, and no internal network hop is
 * ever needed because there is no second process at all once the handoff
 * happens.
 *
 * Sequence:
 *   1. Open PUBLIC_PORT immediately with a tiny placeholder HTTP server,
 *      satisfying Hostinger's "called listen() within a few seconds"
 *      check and answering any request with an honest "starting up".
 *   2. Copy pb_data to a local tmp dir (fast boot; avoids the shipped
 *      copy's directory for migrations/hooks that only need to run once).
 *   3. After a short grace window, close the placeholder and call
 *      execve() to replace this exact process with PocketBase, bound
 *      directly to PUBLIC_PORT. From this point on, PocketBase serves the
 *      API and the built React app (pb_public) itself — there is no Node
 *      process left in the request path at all.
 *
 * If PocketBase ever crashes, this whole OS process exits (there's no
 * Node supervisor left alive to catch it, since Node's own code no longer
 * exists in this process) — Hostinger's own platform is relied on to
 * notice the entry process died and restart `node server.js` fresh, which
 * re-runs this entire sequence from scratch.
 */

const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const { execFile } = require('child_process');

console.log(`[server.js] host arch=${process.arch} platform=${process.platform} node=${process.version}`);
console.log(`[server.js] process.env.PORT=${process.env.PORT}`);

const PUBLIC_PORT = process.env.PORT || 8080;
const HOST = '0.0.0.0';
const HANDOFF_GRACE_MS = 1000;

const ROOT = __dirname;
const PB_BINARY = path.join(ROOT, 'pocketbase');
const NAPI_EXECVE = path.join(ROOT, 'napi_execve.node');

process.on('uncaughtException', (err) => {
  console.error('[server.js] uncaughtException:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (err) => {
  console.error('[server.js] unhandledRejection:', err && err.stack ? err.stack : err);
});

if (!fs.existsSync(PB_BINARY)) {
  console.error(`[server.js] PocketBase binary not found at ${PB_BINARY}`);
  process.exit(1);
}
try {
  fs.chmodSync(PB_BINARY, 0o755);
} catch (err) {
  console.error('[server.js] Could not chmod PocketBase binary (continuing anyway):', err.message);
}

let execve = null;
try {
  execve = require(NAPI_EXECVE).execve;
  console.log('[server.js] loaded native execve helper OK.');
} catch (err) {
  console.error('[server.js] FATAL: could not load native execve helper:', err && err.stack ? err.stack : err);
}

execFile(PB_BINARY, ['--version'], { timeout: 8000 }, (err, stdout, stderr) => {
  if (err) {
    console.error(`[server.js] SANITY CHECK FAILED: ${PB_BINARY} --version errored: ${err.message}`);
  } else {
    console.log(`[server.js] SANITY CHECK OK: ${PB_BINARY} --version -> ${stdout.trim() || stderr.trim()}`);
  }
});

// Copy pb_data to a local tmp dir before first start (fast; keeps the
// shipped copy under ROOT pristine in case of a reset).
const PB_DATA_SRC = path.join(ROOT, 'pb_data');
const PB_DATA_RUN = path.join(os.tmpdir(), 'appobra_pb_data');
try {
  if (!fs.existsSync(PB_DATA_RUN)) {
    console.log(`[server.js] copying pb_data from ${PB_DATA_SRC} to local tmp dir ${PB_DATA_RUN}...`);
    fs.cpSync(PB_DATA_SRC, PB_DATA_RUN, { recursive: true });
    console.log(`[server.js] copy to ${PB_DATA_RUN} complete.`);
  } else {
    console.log(`[server.js] reusing existing local tmp pb_data at ${PB_DATA_RUN}.`);
  }
} catch (err) {
  console.error(`[server.js] failed to copy pb_data to ${PB_DATA_RUN}:`, err && err.stack ? err.stack : err);
}

const PB_ARGS = [
  PB_BINARY,
  'serve',
  `--http=0.0.0.0:${PUBLIC_PORT}`,
  `--dir=${PB_DATA_RUN}`,
  `--migrationsDir=${path.join(ROOT, 'pb_migrations')}`,
  `--hooksDir=${path.join(ROOT, 'pb_hooks')}`,
  '--hooksWatch=false',
  `--publicDir=${path.join(ROOT, 'pb_public')}`,
];

const placeholderServer = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('APP OBRA is starting up, please retry in a moment.');
});

placeholderServer.on('error', (err) => {
  console.error(`[server.js] placeholder server error (code=${err.code}):`, err.message);
});

placeholderServer.listen(PUBLIC_PORT, HOST, () => {
  console.log(`[server.js] placeholder listening on ${HOST}:${PUBLIC_PORT}, pid=${process.pid}.`);

  setTimeout(() => {
    placeholderServer.close(() => {
      console.log(`[server.js] placeholder closed. About to become PocketBase via execve (pid stays ${process.pid}).`);

      if (!execve) {
        console.error('[server.js] FATAL: no native execve helper available, cannot hand off to PocketBase. Exiting.');
        process.exit(1);
        return;
      }

      try {
        execve(PB_BINARY, PB_ARGS);
        // If we get here, execve failed (it never returns on success).
        console.error('[server.js] FATAL: execve returned without replacing the process — this should never happen.');
        process.exit(1);
      } catch (err) {
        console.error('[server.js] FATAL: execve threw:', err && err.message ? err.message : err);
        process.exit(1);
      }
    });
  }, HANDOFF_GRACE_MS);
});
