#!/usr/bin/env node
'use strict';

/*
 * APP OBRA — supervisor for Hostinger Node.js app hosting.
 *
 * CONFIRMED (via diagnostics) about this hosting environment:
 *  - Hostinger's Node.js app hosting requires the Node.js process itself to
 *    call listen() on the assigned port (process.env.PORT) within a few
 *    seconds of starting, as a health check.
 *  - Loopback TCP connections to any port OTHER than the assigned public
 *    port are blocked/refused at the host level — confirmed even with a
 *    pure Node-to-Node self-connect, no PocketBase involved. This rules out
 *    any "Node proxies to PocketBase on an internal port" architecture.
 *  - PocketBase does not support Unix domain sockets (--http is TCP-only).
 *  - PocketBase itself runs completely normally (confirmed via redirecting
 *    its stdout/stderr to a file and tailing it) once it has a usable data
 *    directory — the earlier "never responds" symptom was entirely about
 *    the internal-port network restriction above, not PocketBase itself.
 *
 * Given all that, this script does a PORT HANDOFF instead of a proxy:
 *   1. Open PUBLIC_PORT immediately with a tiny placeholder HTTP server,
 *      satisfying Hostinger's "called listen() within a few seconds" check
 *      and answering any request with a honest "starting up" response.
 *   2. Copy pb_data to a local tmp dir (fast; avoids any slower storage
 *      under the app's own directory) and spawn PocketBase.
 *   3. After a short grace window (long enough for Hostinger's initial
 *      health probe to have hit the placeholder), close the placeholder
 *      and let PocketBase bind PUBLIC_PORT directly — PocketBase then
 *      serves all real traffic (API + built React app) itself, with no
 *      Node proxy in the request path at all.
 *   4. If PocketBase ever exits/crashes, re-open the placeholder
 *      immediately (so the port never goes fully dark) while it restarts,
 *      then hand off again once it's up.
 *
 * Every error path logs loudly instead of crashing silently, because a
 * silent crash here means Hostinger's platform has nothing to show and no
 * clear signal to restart on.
 */

const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const { spawn, execFile } = require('child_process');

console.log(`[server.js] host arch=${process.arch} platform=${process.platform} node=${process.version}`);
console.log(`[server.js] process.env.PORT=${process.env.PORT}`);

const PUBLIC_PORT = process.env.PORT || 8080;
const HOST = '0.0.0.0';
const HANDOFF_GRACE_MS = 2000; // time to keep the placeholder up before handing off
const RESTART_DELAY_MS = 3000; // time to wait before retrying PocketBase after a crash

const ROOT = __dirname;
const PB_BINARY = path.join(ROOT, 'pocketbase');

process.on('uncaughtException', (err) => {
  console.error('[server.js] uncaughtException:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (err) => {
  console.error('[server.js] unhandledRejection:', err && err.stack ? err.stack : err);
});

if (!fs.existsSync(PB_BINARY)) {
  console.error(`[server.js] PocketBase binary not found at ${PB_BINARY}`);
  process.exit(1);
}

try {
  fs.chmodSync(PB_BINARY, 0o755);
} catch (err) {
  console.error('[server.js] Could not chmod PocketBase binary (continuing anyway):', err.message);
}

// Quick, cheap sanity check: can this binary even execute on this host at
// all? (Kept from earlier diagnostics — cheap and still useful signal.)
execFile(PB_BINARY, ['--version'], { timeout: 8000 }, (err, stdout, stderr) => {
  if (err) {
    console.error(`[server.js] SANITY CHECK FAILED: ${PB_BINARY} --version errored: ${err.message}`);
  } else {
    console.log(`[server.js] SANITY CHECK OK: ${PB_BINARY} --version -> ${stdout.trim() || stderr.trim()}`);
  }
});

// Copy pb_data to a local tmp dir before first start (fast; keeps the
// shipped copy under ROOT pristine in case we need to reset).
const PB_DATA_SRC = path.join(ROOT, 'pb_data');
const PB_DATA_RUN = path.join(os.tmpdir(), 'appobra_pb_data');
try {
  if (!fs.existsSync(PB_DATA_RUN)) {
    console.log(`[server.js] copying pb_data from ${PB_DATA_SRC} to local tmp dir ${PB_DATA_RUN}...`);
    fs.cpSync(PB_DATA_SRC, PB_DATA_RUN, { recursive: true });
    console.log(`[server.js] copy to ${PB_DATA_RUN} complete.`);
  } else {
    console.log(`[server.js] reusing existing local tmp pb_data at ${PB_DATA_RUN}.`);
  }
} catch (err) {
  console.error(`[server.js] failed to copy pb_data to ${PB_DATA_RUN}:`, err && err.stack ? err.stack : err);
}

const PB_ARGS = [
  'serve',
  `--http=0.0.0.0:${PUBLIC_PORT}`,
  `--dir=${PB_DATA_RUN}`,
  `--migrationsDir=${path.join(ROOT, 'pb_migrations')}`,
  `--hooksDir=${path.join(ROOT, 'pb_hooks')}`,
  '--hooksWatch=false',
  `--publicDir=${path.join(ROOT, 'pb_public')}`,
];

// Route PocketBase's own stdout/stderr to a plain file and tail it into our
// own console.log — confirmed necessary in this environment, since
// `stdio: 'inherit'` did not surface PocketBase's output in Hostinger's
// runtime-logs even though PocketBase was running fine.
const PB_LOG_FILE = path.join(os.tmpdir(), 'appobra_pb_output.log');
let pbLogTailPos = 0;
let pbLogTailTimer = null;
function startPbLogTail() {
  if (pbLogTailTimer) return;
  pbLogTailPos = 0;
  pbLogTailTimer = setInterval(() => {
    try {
      const st = fs.statSync(PB_LOG_FILE);
      if (st.size > pbLogTailPos) {
        const fd = fs.openSync(PB_LOG_FILE, 'r');
        const len = st.size - pbLogTailPos;
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, pbLogTailPos);
        fs.closeSync(fd);
        pbLogTailPos = st.size;
        buf.toString('utf8').split('\n').filter((l) => l.length > 0).forEach((line) => {
          console.log(`[pocketbase-output] ${line}`);
        });
      }
    } catch (err) {
      if (err.code !== 'ENOENT') {
        console.error('[server.js] error tailing pb log file:', err.message);
      }
    }
  }, 1000);
}
function stopPbLogTail() {
  if (pbLogTailTimer) {
    clearInterval(pbLogTailTimer);
    pbLogTailTimer = null;
  }
}

let shuttingDown = false;
let pbChild = null;
let placeholderServer = null;
let placeholderListening = false;

// --- Placeholder server: opened immediately on startup, and re-opened
// whenever PocketBase is down, so the public port is never fully dark. ---
function openPlaceholder(cb) {
  if (placeholderServer) {
    if (cb) cb();
    return;
  }
  const srv = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('APP OBRA is starting up, please retry in a moment.');
  });
  srv.on('error', (err) => {
    console.error(`[server.js] placeholder server error (code=${err.code}):`, err.message);
    if (err.code === 'EADDRINUSE' && !shuttingDown) {
      setTimeout(() => {
        try { srv.close(); } catch (e) { /* ignore */ }
        placeholderServer = null;
        placeholderListening = false;
        openPlaceholder(cb);
      }, 500);
    }
  });
  srv.listen(PUBLIC_PORT, HOST, () => {
    placeholderListening = true;
    console.log(`[server.js] placeholder listening on ${HOST}:${PUBLIC_PORT}`);
    if (cb) cb();
  });
  placeholderServer = srv;
}

function closePlaceholder(cb) {
  if (!placeholderServer) {
    if (cb) cb();
    return;
  }
  const srv = placeholderServer;
  placeholderServer = null;
  placeholderListening = false;
  try {
    srv.close(() => {
      console.log('[server.js] placeholder closed, handing off port to PocketBase.');
      if (cb) cb();
    });
  } catch (e) {
    if (cb) cb();
  }
}

function startPocketBase() {
  console.log(`[server.js] starting (pid will follow): ${PB_BINARY} ${PB_ARGS.join(' ')}`);

  let child;
  let logFd;
  try {
    fs.writeFileSync(PB_LOG_FILE, '');
    pbLogTailPos = 0;
    logFd = fs.openSync(PB_LOG_FILE, 'a');
  } catch (err) {
    console.error('[server.js] could not prepare pb log file, falling back to inherit:', err.message);
    logFd = 'inherit';
  }
  try {
    child = spawn(PB_BINARY, PB_ARGS, {
      cwd: ROOT,
      stdio: logFd === 'inherit' ? 'inherit' : ['ignore', logFd, logFd],
      env: process.env,
    });
    if (logFd !== 'inherit') {
      try { fs.closeSync(logFd); } catch (e) { /* parent's dup; child keeps its own */ }
    }
  } catch (err) {
    console.error('[server.js] spawn() threw synchronously:', err);
    if (!shuttingDown) setTimeout(handoffCycle, RESTART_DELAY_MS);
    return null;
  }

  startPbLogTail();
  console.log(`[server.js] PocketBase child spawned with pid=${child.pid}, now serving ${HOST}:${PUBLIC_PORT} directly.`);

  child.on('exit', (code, signal) => {
    stopPbLogTail();
    console.error(`[server.js] PocketBase (pid=${child.pid}) exited (code=${code}, signal=${signal}).`);
    pbChild = null;
    if (!shuttingDown) {
      // Port is free again now — reopen the placeholder immediately so it's
      // never fully dark, then retry after a short delay.
      openPlaceholder();
      setTimeout(handoffCycle, RESTART_DELAY_MS);
    }
  });

  child.on('error', (err) => {
    console.error('[server.js] Failed to start PocketBase binary:', err);
  });

  return child;
}

// One full cycle: make sure the placeholder is up, wait out the grace
// window, then close it and spawn PocketBase bound directly to PUBLIC_PORT.
function handoffCycle() {
  if (shuttingDown) return;
  openPlaceholder(() => {
    setTimeout(() => {
      if (shuttingDown) return;
      closePlaceholder(() => {
        pbChild = startPocketBase();
      });
    }, HANDOFF_GRACE_MS);
  });
}

handoffCycle();

function shutdown(signal) {
  console.log(`[server.js] received ${signal}, shutting down...`);
  shuttingDown = true;
  stopPbLogTail();
  if (pbChild && !pbChild.killed) {
    pbChild.kill(signal);
  }
  if (placeholderServer) {
    try { placeholderServer.close(); } catch (e) { /* ignore */ }
  }
  setTimeout(() => process.exit(0), 2000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
