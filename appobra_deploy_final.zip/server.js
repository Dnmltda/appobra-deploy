#!/usr/bin/env node
'use strict';

/*
 * APP OBRA — supervisor + reverse proxy for Hostinger Node.js app hosting.
 *
 * Hostinger's Node.js app hosting requires the Node.js process itself to
 * call listen() on the assigned port (process.env.PORT) within a few
 * seconds of starting, as a health check. PocketBase is a separate Go
 * binary that opens its own socket, so a plain "spawn and wait" supervisor
 * never satisfies that check and gets killed in a restart loop.
 *
 * This script opens the public port immediately with a small Node HTTP
 * server (satisfying Hostinger's health check right away) and transparently
 * proxies every request to PocketBase, which runs on a separate, internal
 * localhost port. PocketBase continues to serve the API AND the built React
 * app (from ./pb_public) itself; Node just forwards bytes.
 *
 * Every error path logs loudly instead of crashing silently, because a
 * silent crash here means Hostinger's platform has nothing to show and no
 * clear signal to restart on.
 */

const path = require('path');
const fs = require('fs');
const http = require('http');
const { spawn } = require('child_process');

const PUBLIC_PORT = process.env.PORT || 8080;
const INTERNAL_PORT = 8090;
const HOST = '0.0.0.0';

const ROOT = __dirname;
const PB_BINARY = path.join(ROOT, 'pocketbase');

process.on('uncaughtException', (err) => {
  console.error('[server.js] uncaughtException:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (err) => {
  console.error('[server.js] unhandledRejection:', err && err.stack ? err.stack : err);
});

if (!fs.existsSync(PB_BINARY)) {
  console.error(`[server.js] PocketBase binary not found at ${PB_BINARY}`);
  process.exit(1);
}

try {
  fs.chmodSync(PB_BINARY, 0o755);
} catch (err) {
  console.error('[server.js] Could not chmod PocketBase binary (continuing anyway):', err.message);
}

const args = [
  'serve',
  `--http=127.0.0.1:${INTERNAL_PORT}`,
  `--dir=${path.join(ROOT, 'pb_data')}`,
  `--migrationsDir=${path.join(ROOT, 'pb_migrations')}`,
  `--hooksDir=${path.join(ROOT, 'pb_hooks')}`,
  '--hooksWatch=false',
  `--publicDir=${path.join(ROOT, 'pb_public')}`,
];

let shuttingDown = false;
let pbProcess = null;

function startPocketBase() {
  console.log(`[server.js] starting: ${PB_BINARY} ${args.join(' ')}`);

  let child;
  try {
    child = spawn(PB_BINARY, args, {
      cwd: ROOT,
      stdio: 'inherit',
      env: process.env,
    });
  } catch (err) {
    console.error('[server.js] spawn() threw synchronously:', err);
    if (!shuttingDown) setTimeout(startPocketBase, 3000);
    return null;
  }

  child.on('exit', (code, signal) => {
    console.error(`[server.js] PocketBase exited (code=${code}, signal=${signal}).`);
    if (!shuttingDown) {
      setTimeout(() => {
        pbProcess = startPocketBase();
      }, 3000);
    }
  });

  child.on('error', (err) => {
    console.error('[server.js] Failed to start PocketBase binary:', err);
  });

  return child;
}

pbProcess = startPocketBase();

// --- Reverse proxy: opens PUBLIC_PORT immediately (Hostinger health check),
// forwards everything to PocketBase on INTERNAL_PORT. ---

const proxyServer = http.createServer((clientReq, clientRes) => {
  const proxyReq = http.request(
    {
      hostname: '127.0.0.1',
      port: INTERNAL_PORT,
      path: clientReq.url,
      method: clientReq.method,
      headers: clientReq.headers,
    },
    (proxyRes) => {
      clientRes.writeHead(proxyRes.statusCode, proxyRes.headers);
      proxyRes.pipe(clientRes, { end: true });
    }
  );

  proxyReq.on('error', (err) => {
    // PocketBase may not be ready yet right after boot, or may be mid-restart.
    if (!clientRes.headersSent) {
      clientRes.writeHead(503, { 'Content-Type': 'text/plain' });
    }
    clientRes.end('Service starting, please retry in a moment.');
  });

  clientReq.pipe(proxyReq, { end: true });
});

// Proxy WebSocket / upgrade requests too (not currently used by PocketBase's
// realtime, which is SSE over plain HTTP, but harmless to support).
proxyServer.on('upgrade', (req, clientSocket, head) => {
  const proxyReq = http.request({
    hostname: '127.0.0.1',
    port: INTERNAL_PORT,
    path: req.url,
    method: req.method,
    headers: req.headers,
  });
  proxyReq.on('upgrade', (proxyRes, proxySocket, proxyHead) => {
    clientSocket.write(
      `HTTP/1.1 101 Switching Protocols\r\n` +
        Object.entries(proxyRes.headers)
          .map(([k, v]) => `${k}: ${v}`)
          .join('\r\n') +
        '\r\n\r\n'
    );
    proxySocket.pipe(clientSocket);
    clientSocket.pipe(proxySocket);
  });
  proxyReq.on('error', () => clientSocket.destroy());
  proxyReq.end();
});

function listenWithRetry(retriesLeft) {
  proxyServer.listen(PUBLIC_PORT, HOST, () => {
    console.log(`[server.js] reverse proxy listening on ${HOST}:${PUBLIC_PORT}, forwarding to 127.0.0.1:${INTERNAL_PORT}`);
  });
}

proxyServer.on('error', (err) => {
  console.error(`[server.js] proxy server error (code=${err.code}):`, err.message);
  if (err.code === 'EADDRINUSE' && !shuttingDown) {
    console.error('[server.js] port still in use, retrying listen() in 1s...');
    setTimeout(() => {
      try {
        proxyServer.close();
      } catch (e) {
        // ignore
      }
      listenWithRetry();
    }, 1000);
  }
});

listenWithRetry();

function shutdown(signal) {
  console.log(`[server.js] received ${signal}, shutting down...`);
  shuttingDown = true; // prevent auto-restart during intentional shutdown
  if (pbProcess && !pbProcess.killed) {
    pbProcess.kill(signal);
  }
  try {
    proxyServer.close(() => process.exit(0));
  } catch (e) {
    process.exit(0);
  }
  // Force exit if close() hangs.
  setTimeout(() => process.exit(0), 2000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
