/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  const email = e.record.get("email");
  const username = e.record.get("username");
  const idUnico = e.record.get("id_unico");
  const inviteToken = e.record.get("password_reset_token");

  // Only send if email exists
  if (!email) {
    e.next();
    return;
  }

  try {
    // Fluxo de convite (ver activate-invite.pb.js): o funcionário foi
    // criado SEM senha utilizável — o próprio funcionário confirma os
    // dados e cria a senha pelo link. Distinto do welcome email antigo,
    // que assumia que o admin já tinha definido e informado uma senha.
    if (inviteToken) {
      const inviteLink = `https://midnightblue-chamois-688707.hostingersite.com/ativar-conta?token=${inviteToken}`;
      const message = new MailerMessage({
        from: {
          address: $app.settings().meta.senderAddress,
          name: "DNM&LTDA OBRAS"
        },
        to: [{ address: email }],
        subject: "Bem-vindo à DNM&LTDA OBRAS — confirme seu cadastro",
        html: `
          <h2>Bem-vindo à DNM&LTDA OBRAS</h2>
          <p>Um acesso foi criado para você no sistema.</p>
          <p><strong>Usuário:</strong> ${username}</p>
          <p><strong>Próximos Passos:</strong></p>
          <ol>
            <li>Clique no link abaixo para confirmar seus dados</li>
            <li>Crie sua própria senha de acesso</li>
            <li>Entre no sistema com seu email e a senha que você criou</li>
          </ol>
          <p><a href="${inviteLink}" style="background-color: #d4af37; color: #1a3a52; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">Confirmar dados e criar senha</a></p>
          <p>Ou copie e cole este link no seu navegador:</p>
          <p>${inviteLink}</p>
          <p><strong>Importante:</strong> Este link expira em 7 dias.</p>
          <p>Se tiver dúvidas, entre em contato com o administrador do sistema.</p>
          <p>Atenciosamente,<br>Equipe DNM&LTDA OBRAS</p>
        `
      });

      $app.newMailClient().send(message);
      e.next();
      return;
    }

    const message = new MailerMessage({
      from: {
        address: $app.settings().meta.senderAddress,
        name: "DNM&LTDA OBRAS"
      },
      to: [{ address: email }],
      subject: "Bem-vindo à DNM&LTDA OBRAS",
      html: `
        <h2>Bem-vindo à DNM&LTDA OBRAS</h2>
        <p>Sua conta foi criada com sucesso!</p>
        <p><strong>Informações de Acesso:</strong></p>
        <ul>
          <li><strong>ID do Usuário:</strong> ${idUnico || e.record.id}</li>
          <li><strong>Usuário:</strong> ${username}</li>
          <li><strong>Email:</strong> ${email}</li>
        </ul>
        <p><strong>Próximos Passos:</strong></p>
        <ol>
          <li>Acesse o sistema em: <a href="https://midnightblue-chamois-688707.hostingersite.com/login">https://midnightblue-chamois-688707.hostingersite.com/login</a></li>
          <li>Use seu email e a senha fornecida pelo administrador</li>
          <li>Altere sua senha na primeira vez que fizer login</li>
        </ol>
        <p>Se tiver dúvidas, entre em contato com o administrador do sistema.</p>
        <p>Atenciosamente,<br>Equipe DNM&LTDA OBRAS</p>
      `
    });

    $app.newMailClient().send(message);
  } catch (err) {
    console.log("Erro ao enviar email de boas-vindas:", err);
  }

  e.next();
}, "users");
