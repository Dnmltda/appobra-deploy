/// <reference path="../pb_data/types.d.ts" />

// Endpoint público para autocadastro (tela de Login -> "Criar conta").
// Cria uma empresa NOVA + o usuário administrador vinculado a ela, de forma
// atômica. Sempre cria uma empresa nova — nunca aceita um company_id vindo
// do cliente — para impedir que alguém se autocadastre dentro dos dados de
// uma empresa já existente. As regras de criação de "companies" e "users"
// continuam exigindo admin autenticado via API normal; este endpoint roda
// com contexto de servidor ($app.save) e por isso não passa por essas regras,
// mas o próprio código nunca reaproveita um company_id existente.
routerAdd("POST", "/api/custom/self-register-company", (e) => {
  const data = new DynamicModel({
    companyName: "",
    cpfCnpj: "",
    companyEmail: "",
    phone: "",
    city: "",
    state: "",
    adminName: "",
    adminEmail: "",
    username: "",
    password: "",
  });
  e.bindBody(data);

  const companyName = String(data.companyName || "").trim();
  const adminName = String(data.adminName || "").trim();
  const adminEmail = String(data.adminEmail || "").trim().toLowerCase();
  const username = String(data.username || "").trim().toLowerCase();
  const password = String(data.password || "");

  if (!companyName || !adminName || !adminEmail || !username || !password) {
    throw new BadRequestError("Preencha nome da empresa, nome, email, usuário e senha.");
  }
  if (password.length < 8) {
    throw new BadRequestError("A senha deve ter pelo menos 8 caracteres.");
  }

  const companiesCol = $app.findCollectionByNameOrId("companies");
  const company = new Record(companiesCol);
  company.set("name", companyName);
  if (data.cpfCnpj) company.set("cnpj", String(data.cpfCnpj).replace(/\D/g, ""));
  if (data.companyEmail) company.set("email", String(data.companyEmail).trim());
  if (data.phone) company.set("phone", String(data.phone).trim());
  if (data.city) company.set("city", String(data.city).trim());
  if (data.state) company.set("state", String(data.state).trim());
  company.set("subscription_tier", "basic");
  company.set("is_active", true);

  try {
    $app.save(company);
  } catch (err) {
    throw new BadRequestError("Erro ao criar empresa: " + err.message);
  }

  const usersCol = $app.findCollectionByNameOrId("users");
  const user = new Record(usersCol);
  user.set("email", adminEmail);
  user.set("username", username);
  user.set("name", adminName);
  user.set("password", password);
  user.set("passwordConfirm", password);
  user.set("company_id", company.id);
  user.set("role", "Administrador");
  user.set("cargo", "Administrador");
  user.set("status", "Ativo");
  user.set("is_active", true);
  user.set("is_blocked", false);
  user.set("login_attempts", 0);

  try {
    $app.save(user);
  } catch (err) {
    try {
      $app.delete(company);
    } catch (rollbackErr) {
      console.log("Falha ao reverter empresa após erro no usuário:", rollbackErr);
    }
    throw new BadRequestError("Erro ao criar administrador: " + err.message);
  }

  // Catálogo padrão de materiais (mesmo usado em
  // pb_migrations/1792400000_seed_materiais_catalogo_padrao.js), pra toda
  // empresa nova já nascer com uma base de materiais pronta — ajuda nas
  // demonstrações do app. Não bloqueia o cadastro se falhar.
  try {
    const materiaisCol = $app.findCollectionByNameOrId("materiais");
    const CATALOGO_PADRAO = [
      { code: "ELE-001", name: "Fio flexível 1,5mm", category: "Elétrica", unit: "m" },
      { code: "ELE-002", name: "Fio flexível 2,5mm", category: "Elétrica", unit: "m" },
      { code: "ELE-003", name: "Fio flexível 4mm", category: "Elétrica", unit: "m" },
      { code: "ELE-004", name: "Disjuntor DIN 20A", category: "Elétrica", unit: "un" },
      { code: "ELE-005", name: "Tomada 2P+T 10A", category: "Elétrica", unit: "un" },
      { code: "HID-001", name: "Tubo PVC soldável 25mm (3/4\")", category: "Hidráulica", unit: "m" },
      { code: "HID-002", name: "Tubo PVC soldável 50mm (1.1/2\")", category: "Hidráulica", unit: "m" },
      { code: "HID-003", name: "Joelho PVC 90° 25mm", category: "Hidráulica", unit: "un" },
      { code: "HID-004", name: "Torneira de parede 1/2\"", category: "Hidráulica", unit: "un" },
      { code: "CON-001", name: "Cimento CP II 50kg", category: "Materiais de Construção", unit: "un" },
      { code: "CON-002", name: "Areia média lavada", category: "Materiais de Construção", unit: "m3" },
      { code: "CON-003", name: "Tijolo cerâmico 6 furos", category: "Materiais de Construção", unit: "un" },
      { code: "CON-004", name: "Brita nº1", category: "Materiais de Construção", unit: "m3" },
      { code: "ACB-001", name: "Tinta acrílica branca 18L", category: "Pintura", unit: "un" },
      { code: "ACB-002", name: "Piso cerâmico 45x45", category: "Acabamento", unit: "m2" },
      { code: "ACB-003", name: "Argamassa ACIII 20kg", category: "Acabamento", unit: "un" },
      { code: "FER-001", name: "Prego 17x27", category: "Ferragens", unit: "kg" },
      { code: "FER-002", name: "Parafuso drywall 3,5x25mm", category: "Ferragens", unit: "un" },
    ];
    CATALOGO_PADRAO.forEach((item) => {
      const material = new Record(materiaisCol);
      material.set("company_id", company.id);
      material.set("code", item.code);
      material.set("name", item.name);
      material.set("category", item.category);
      material.set("unit", item.unit);
      material.set("quantity_in_stock", 0);
      material.set("min_quantity", 0);
      material.set("unit_cost", 0);
      material.set("status", "active");
      $app.save(material);
    });
  } catch (seedErr) {
    console.log("Erro ao semear catálogo padrão de materiais:", seedErr);
  }

  return e.json(200, {
    success: true,
    companyId: company.id,
    companyName: company.get("name"),
    userId: user.id,
  });
})
