/// <reference path="../pb_data/types.d.ts" />

// Fluxo de convite de funcionário: o admin cria o funcionário + o acesso
// (EmployeeManagement.jsx -> criarAcessoParaFuncionario) SEM definir uma
// senha utilizável. O usuário é criado com status "Inativo" e com
// password_reset_token/password_reset_expires já preenchidos (mesmos campos
// usados em "esqueci minha senha"). O hook send-welcome-email.pb.js detecta
// esse token e envia um email de convite com link para /ativar-conta.
//
// Estes dois endpoints públicos (sem autenticação, pois o funcionário ainda
// não tem como logar) rodam com contexto de servidor ($app.save) e por isso
// não passam pelas regras normais da collection "users" — seguem o mesmo
// padrão já usado em routerAdd("POST", "/api/custom/self-register-company")
// em send-welcome-email.pb.js.

const findUserByValidToken = (token) => {
  const cleanToken = String(token || "").trim();
  if (!cleanToken) return null;

  const usersCol = $app.findCollectionByNameOrId("users");
  let user;
  try {
    // Mesmo estilo de filtro (interpolação direta) já usado em todo o
    // restante do código — não a sintaxe de parâmetros nomeados "{:token}",
    // que não é usada em nenhum outro ponto deste projeto.
    user = $app.findFirstRecordByFilter(usersCol, `password_reset_token = "${cleanToken}"`);
  } catch (err) {
    return null;
  }
  if (!user) return null;

  const expires = user.get("password_reset_expires");
  if (!expires) return null;
  if (new Date(expires).getTime() < Date.now()) return null;

  return user;
};

// Retorna os dados do funcionário/usuário para a tela "Confirme seus dados",
// sem expor nada sensível (sem senha, sem outros usuários da empresa).
routerAdd("POST", "/api/custom/get-invite-details", (e) => {
  const data = new DynamicModel({ token: "" });
  e.bindBody(data);

  const user = findUserByValidToken(data.token);
  if (!user) {
    throw new BadRequestError("Link de convite inválido ou expirado.");
  }

  let funcionario = null;
  const funcionarioId = user.get("funcionario_id");
  if (funcionarioId) {
    try {
      const funcCol = $app.findCollectionByNameOrId("funcionarios");
      const funcRecord = $app.findRecordById(funcCol, funcionarioId);
      funcionario = {
        nome: funcRecord.get("nome"),
        cpf: funcRecord.get("cpf"),
        cargo: user.get("cargo"),
        departamento: funcRecord.get("departamento"),
        telefone: funcRecord.get("telefone"),
      };
    } catch (err) {
      // Funcionário pode ter sido excluído depois do convite — segue só com os dados do usuário.
    }
  }

  return e.json(200, {
    success: true,
    name: user.get("name"),
    email: user.get("email"),
    username: user.get("username"),
    cargo: user.get("cargo"),
    telefone: user.get("telefone"),
    funcionario,
  });
})

// Confirma os dados (implícito: o funcionário só chega aqui vendo a tela
// anterior) e define a senha definitiva. Marca o usuário como "Ativo" e
// invalida o token para não poder ser reusado.
routerAdd("POST", "/api/custom/activate-invite", (e) => {
  const data = new DynamicModel({ token: "", password: "", passwordConfirm: "" });
  e.bindBody(data);

  const password = String(data.password || "");
  const passwordConfirm = String(data.passwordConfirm || "");

  if (password.length < 8) {
    throw new BadRequestError("A senha deve ter pelo menos 8 caracteres.");
  }
  if (password !== passwordConfirm) {
    throw new BadRequestError("As senhas não conferem.");
  }

  const user = findUserByValidToken(data.token);
  if (!user) {
    throw new BadRequestError("Link de convite inválido ou expirado.");
  }

  user.set("password", password);
  user.set("passwordConfirm", passwordConfirm);
  user.set("password_reset_token", "");
  user.set("password_reset_expires", "");
  user.set("status", "Ativo");
  user.set("is_active", true);

  try {
    $app.save(user);
  } catch (err) {
    throw new BadRequestError("Erro ao ativar a conta: " + err.message);
  }

  return e.json(200, { success: true });
})
