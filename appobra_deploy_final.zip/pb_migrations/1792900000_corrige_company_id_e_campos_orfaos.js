/// <reference path="../pb_data/types.d.ts" />

// Corrige dois problemas que impediam o cadastro de Solicitações, o uso do
// módulo de Compras (itens/aprovação/recebimento/anexos) e qualquer
// Movimentação de Estoque (Entrada, Saída, Retirada por Funcionário etc).
//
// PROBLEMA 1 — "Failed to create record." ao criar uma Solicitação:
// o campo "company_id" das collections solicitacoes, solicitacoes_aprovacao,
// solicitacoes_anexos, compras_itens, compras_aprovacao, compras_recebimento
// e compras_anexos foi criado apontando (collectionId) para a collection
// "empresas" — que é o cadastro de empresas (clientes/parceiras), outro
// recurso do app, sem relação com o usuário logado. O "company_id" de
// verdade (a empresa/conta de quem está logado) vive na collection
// "companies" (a mesma usada em users.company_id, materiais.company_id,
// movimentacoes.company_id etc). Como o front sempre envia o ID de
// "companies", mas o campo só aceitava IDs existentes em "empresas", a
// validação do relacionamento falhava sempre e o PocketBase respondia o
// genérico "Failed to create record.", sem detalhar qual campo.
//
// PROBLEMA 2 — "Cannot be blank., Cannot be blank." ao registrar uma
// Movimentação de estoque (inclusive "Retirada por Funcionário"):
// a collection "movimentacoes" tem dois campos obrigatórios órfãos, nunca
// preenchidos pelo código atual nem usados em nenhuma tela:
//   - "quantity": campo legado da criação original da collection,
//     substituído na prática por "quantidade", mas nunca removido;
//   - "company_id_new": campo duplicado de "company_id", sobra de uma
//     tentativa antiga de migração de multi-tenant que não foi concluída.
// O mesmo "company_id_new" órfão também ficou em "equipamentos" e
// "emprestimos" (mesma causa, mesmo tipo de sobra). Como nada no app
// preenche esses campos, toda criação falhava com dois "Cannot be blank.".
//
// Nenhuma dessas collections tinha registros usando esses campos (as
// criações sempre falhavam antes), então não há dado existente a migrar —
// só a definição do schema é corrigida.

migrate(
  (app) => {
    const companies = app.findCollectionByNameOrId("companies");

    const fixCompanyId = (collectionName) => {
      let col;
      try {
        col = app.findCollectionByNameOrId(collectionName);
      } catch (_) {
        return; // collection não existe neste ambiente, ignora
      }
      const field = col.fields.getByName("company_id");
      if (!field) return;
      if (field.collectionId === companies.id) return; // já está correto

      col.fields.removeByName("company_id");
      col.fields.add(
        new RelationField({
          name: "company_id",
          collectionId: companies.id,
          maxSelect: 1,
          cascadeDelete: false,
          required: true,
        }),
      );
      app.save(col);
    };

    [
      "solicitacoes",
      "solicitacoes_aprovacao",
      "solicitacoes_anexos",
      "compras_itens",
      "compras_aprovacao",
      "compras_recebimento",
      "compras_anexos",
    ].forEach(fixCompanyId);

    const removeOrphanField = (collectionName, fieldName) => {
      let col;
      try {
        col = app.findCollectionByNameOrId(collectionName);
      } catch (_) {
        return;
      }
      if (!col.fields.getByName(fieldName)) return;
      col.fields.removeByName(fieldName);
      app.save(col);
    };

    removeOrphanField("movimentacoes", "quantity");
    removeOrphanField("movimentacoes", "company_id_new");
    removeOrphanField("equipamentos", "company_id_new");
    removeOrphanField("emprestimos", "company_id_new");
  },
  (app) => {
    // Down: devolve o company_id para "empresas" só para espelhar o estado
    // anterior (não recomendado reativar — era o próprio bug). Os campos
    // órfãos removidos não são recriados, pois eram lixo de migração.
    let empresas;
    try {
      empresas = app.findCollectionByNameOrId("empresas");
    } catch (_) {
      return;
    }

    const revertCompanyId = (collectionName) => {
      try {
        const col = app.findCollectionByNameOrId(collectionName);
        if (!col.fields.getByName("company_id")) return;
        col.fields.removeByName("company_id");
        col.fields.add(
          new RelationField({
            name: "company_id",
            collectionId: empresas.id,
            maxSelect: 1,
            cascadeDelete: false,
            required: true,
          }),
        );
        app.save(col);
      } catch (_) {
        // ignora collections que não existam neste ambiente
      }
    };

    [
      "solicitacoes",
      "solicitacoes_aprovacao",
      "solicitacoes_anexos",
      "compras_itens",
      "compras_aprovacao",
      "compras_recebimento",
      "compras_anexos",
    ].forEach(revertCompanyId);
  },
);
