/// <reference path="../pb_data/types.d.ts" />
// Configura o envio de e-mails (convite de funcionarios, etc.) usando o
// Brevo como provedor SMTP transacional. Antes disso settings.smtp estava
// totalmente vazio/desabilitado, por isso nenhum e-mail (nem o de convite
// de acesso, nem o de boas-vindas) jamais foi enviado.
//
// Chave SMTP gerada especificamente para o APP OBRA (Brevo > SMTP & API),
// separada da chave usada no site institucional da DNM&LTDA.
migrate((app) => {
    let settings = app.settings()

    settings.smtp.enabled = true
    settings.smtp.host = "smtp-relay.brevo.com"
    settings.smtp.port = 587
    settings.smtp.username = "b80108001@smtp-brevo.com"
    settings.smtp.password = "xsmtpsib-84cf0d38eea1e1f7b0ab915d334de2f9d85454ac4ba2d4936b1e44d95029eb76-n3ZnLAtrlOBTmXo5"
    // Porta 587 usa STARTTLS (conexao comeca em texto plano e so depois
    // upgrada para TLS) - "tls: true" forcaria TLS implicito desde o
    // inicio da conexao, o que quebraria nessa porta.
    settings.smtp.tls = false
    settings.smtp.authMethod = "PLAIN"

    // Remetente verificado no Brevo (Remetentes > Verificado).
    settings.meta.senderName = "DNM&LTDA"
    settings.meta.senderAddress = "dnmltda@hotmail.com"

    app.save(settings)
}, (app) => {
    let settings = app.settings()

    settings.smtp.enabled = false
    settings.smtp.host = ""
    settings.smtp.port = 0
    settings.smtp.username = ""
    settings.smtp.password = ""
    settings.smtp.tls = false
    settings.smtp.authMethod = ""

    app.save(settings)
})
